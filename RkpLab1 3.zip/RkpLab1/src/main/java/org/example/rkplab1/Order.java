package org.example.rkplab1;

import java.sql.Date;

public class Order {

    private int id;
    private String dishName;
    private Date date;
    private int orderAmount;
    private int orderNumber;
    private double price;


    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getSum() {
        return sum;
    }

    @Override
    public String toString() {
        return "Order{" +
                "id=" + id +
                ", dishName='" + dishName + '\'' +
                ", date=" + date +
                ", orderAmount=" + orderAmount +
                ", orderNumber=" + orderNumber +
                ", price=" + price +
                ", sum=" + sum +
                '}';
    }

    public void setSum(double sum) {
        this.sum = sum;
    }

    private double sum;

    public Order(int orderId,String dishName, int numberOfDishes, double price, double sum) {
        this.id = orderId;
        this.dishName = dishName;
        this.price = price;
        this.sum = sum;
        this.orderNumber = numberOfDishes;
    }

    public int getOrderNumber() {
        return orderNumber;
    }
    public void setOrderNumber(int orderNumber) {
        this.orderNumber = orderNumber;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDishName() {
        return dishName;
    }

    public void setDishName(String dishName) {
        this.dishName = dishName;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
    public int getOrderAmount() {
        return orderAmount;
    }
    public void setOrderAmount(int orderAmount) {
        this.orderAmount = orderAmount;
    }
    public Order(int id, String dishName, Date date, int orderAmount,int orderNumber) {
        this.id = id;
        this.dishName = dishName;
        this.date = date;
        this.orderAmount = orderAmount;
        this.orderNumber = orderNumber;
    }
}
