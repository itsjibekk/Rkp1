package org.example.rkplab1;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.sql.Date;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

public class OrdersController implements Initializable {

    @FXML
    private Button delete;
    @FXML
    private Button deleteFromOrders;
    @FXML
    private Button backToMain;

    @FXML
    private Button add;

    @FXML
    private TableView<Dish> dishes = new TableView<>();

    @FXML
    private TableView<OrderItem> myOrder = new TableView<>();

    @FXML
    private Button getReport;

    @FXML
    private Button save;

    @FXML
    private Button generateDetailed;

    @FXML
    private TableView<Orderr> tableView = new TableView<Orderr>();

    @FXML
    Label labelSum = new Label();

    ObservableList<OrderItem> selectedOrderItems = FXCollections.observableArrayList();

    public  ObservableList<Dish> selectedDishes = FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        TableColumn id = new TableColumn("ID");
        TableColumn dishName = new TableColumn("Наименование блюда");

        TableColumn orderAmount = new TableColumn("Количество заказа");
        TableColumn orderNumber = new TableColumn("Номер заказа");
        TableColumn price = new TableColumn("Цена");

        TableColumn<Orderr, Integer> idd = new TableColumn<>("Номер заказа");
        TableColumn<Orderr, Timestamp> date = new TableColumn<>("Дата");
        TableColumn<Orderr, Integer> total = new TableColumn<>("Итого");
        TableColumn addButton = new TableColumn("Количество");
        dishes.getColumns().clear();

        tableView.getColumns().addAll(idd,total,date);
        dishes.getColumns().addAll(id,dishName,price,addButton);

        final ObservableList<Orderr> data = loadOrders();
        final ObservableList<Dish>  myDishes = loadDishesFromDb();

        idd.setCellValueFactory(new PropertyValueFactory<>("id"));
        date.setCellValueFactory(new PropertyValueFactory<>("orderDate"));
        total.setCellValueFactory(new PropertyValueFactory<>("total"));


        id.setCellValueFactory(new PropertyValueFactory<Dish, Integer>("id"));
        dishName.setCellValueFactory(new PropertyValueFactory<Dish, String>("dishName"));
        orderAmount.setCellValueFactory(new PropertyValueFactory<Dish, String>("orderAmount"));
        orderNumber.setCellValueFactory(new PropertyValueFactory<Dish, String>("orderNumber"));
        price.setCellValueFactory(new PropertyValueFactory<Dish,Integer>("price"));

        id.setMinWidth(37);
        dishName.setMinWidth(194);
        price.setMinWidth(79);
        addButton.setMinWidth(165);

        addButton.setCellFactory(param -> new TableCell<Dish, Void>() {
            private final Button button = new Button("Add to Order");
            private final TextField textField = new TextField();
            private final HBox hbox = new HBox(5, textField, button); // Spacing of 5 between TextField and Button

            {
                textField.setPromptText("Сколько"); // Placeholder text
                textField.setPrefWidth(50); // Set preferred width for the TextField

                button.setOnAction(event -> {
                    Dish dish = (Dish) getTableView().getItems().get(getIndex());
                    try {
                        int quantity = Integer.parseInt(textField.getText().trim());
                        if (quantity > 0) {
                            // Add the dish with the specified quantity to the order
                            for (int i = 0; i < quantity; i++) {
                                selectedDishes.add(dish);
                            }
                        } else {
                            // Show alert for invalid quantity
                            Alert alert = new Alert(Alert.AlertType.WARNING);
                            alert.setTitle("Invalid Quantity");
                            alert.setHeaderText(null);
                            alert.setContentText("Количество должно быть больше 0");
                            alert.showAndWait();
                        }
                    } catch (NumberFormatException e) {
                        // Show alert for invalid input
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Invalid Input");
                        alert.setHeaderText(null);
                        alert.setContentText("Please enter a valid number for the quantity.");
                        alert.showAndWait();
                    }
                });

            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(hbox); // Set the HBox containing the TextField and Button
                }
            }
        });


        updateTotalSum(selectedOrderItems, labelSum);
        selectedOrderItems.addListener((ListChangeListener<OrderItem>) change -> updateTotalSum(selectedOrderItems, labelSum));
        tableView.setItems(data);
        dishes.setItems(myDishes);

    }

    private ObservableList<Orderr> loadOrders() {
        ArrayList<Orderr> orders = new ArrayList<>();
        try {
            Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
            Statement stmt = conn.createStatement();
            Statement statement = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String query = "SELECT * FROM \"orders\";";
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                int id = rs.getInt("id");
                Timestamp date = rs.getTimestamp("orderdate");
                int total = rs.getInt("total");

                orders.add(new Orderr(id,total, date.toLocalDateTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))));
            }

            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return FXCollections.observableArrayList(orders);

    }

    private int updateTotalSum(ObservableList<OrderItem> data, Label totalSumLabel) {
        double totalSum = data.stream()
                .mapToDouble(item -> item.getOrderAmount() * item.getDish().getPrice())
                .sum();
        totalSumLabel.setText(totalSum + " c");
        return (int) totalSum;
    }

    public void startOrder() {

        Map<Dish, Integer> uniqueDishes = selectedDishes.stream()
                .collect(Collectors.toMap(
                        dish -> dish,         // ключ: блюдо
                        dish -> 1,            // значение: 1 (начальное значение)
                        Integer::sum          // суммируем значения при совпадении ключей
                ));

        selectedOrderItems.clear();

        for(Map.Entry<Dish, Integer> dish : uniqueDishes.entrySet()){
            OrderItem orderItem = new OrderItem(dish.getKey(),dish.getValue());
            selectedOrderItems.add(orderItem);
        }
        myOrder.setItems(FXCollections.observableArrayList(selectedOrderItems));


        myOrder.getColumns().clear();
        TableColumn<OrderItem, Integer> idColumn = new TableColumn<>("ID");
        TableColumn<OrderItem, String> dishNameColumn = new TableColumn<>("Наименование блюда");
        TableColumn<OrderItem, Integer> orderAmountColumn = new TableColumn<>("Количество заказа");
        TableColumn<OrderItem, Double> sumColumn = new TableColumn<>("Сумма");

        idColumn.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getDish().getId()).asObject());
        dishNameColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getDish().getDishName()));
        orderAmountColumn.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getOrderAmount()).asObject());
        sumColumn.setCellValueFactory(cellData -> new SimpleDoubleProperty(cellData.getValue().getOrderAmount() * cellData.getValue().getDish().getPrice()).asObject());

        myOrder.getColumns().addAll(idColumn, dishNameColumn, orderAmountColumn, sumColumn);
    }
     public void delete(){
        Orderr orderr = tableView.getSelectionModel().getSelectedItem();
        tableView.getItems().remove(orderr);
        tableView.refresh();
         Connection conn = null;
         try {
             String query = "DELETE FROM orders where id = ?";
             conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
             PreparedStatement stmt = conn.prepareStatement(query);
             stmt.setLong(1,orderr.getId());
             stmt.executeUpdate();
         } catch (SQLException e) {
             throw new RuntimeException(e);
         }

    }

    public void addOrder() {
        String insertOrder = "INSERT INTO \"orders\" (total, orderdate) VALUES (?, ?)";
        String insertOrderDetail = "INSERT INTO \"order\" (dishid, numberofdishes, orderid) VALUES (?, ?, ?)";
        try {
            LocalDateTime localDateTime = LocalDateTime.now();
            Timestamp sqlTimestamp = Timestamp.valueOf(localDateTime);
            Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");

            // Insert order
            PreparedStatement psOrder = conn.prepareStatement(insertOrder, Statement.RETURN_GENERATED_KEYS);
            psOrder.setInt(1, updateTotalSum(selectedOrderItems, labelSum));
            psOrder.setTimestamp(2, sqlTimestamp);
            psOrder.executeUpdate();

            // Get the generated order ID
            ResultSet generatedKeys = psOrder.getGeneratedKeys();
            int orderId = -1;
            if (generatedKeys.next()) {
                orderId = generatedKeys.getInt(1);
            }

            // Insert order details
            PreparedStatement psOrderDetail = conn.prepareStatement(insertOrderDetail);
            for (OrderItem item : selectedOrderItems) {
                psOrderDetail.setInt(1, item.getDish().getId());
                psOrderDetail.setInt(2, item.getOrderAmount());
                psOrderDetail.setInt(3, orderId);
                psOrderDetail.executeUpdate();
            }

            conn.close();

            // Show confirmation alert
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setHeaderText(null);
            alert.setContentText("Order added successfully!");
            alert.showAndWait();

            // Navigate to the previous page
            backToOrders();

        } catch (SQLException e) {
            e.printStackTrace();

            // Show error alert
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Could not add order");
            alert.setContentText("An error occurred while adding the order. Please try again.");
            alert.showAndWait();
        }
    }


    public ObservableList<Dish> loadDishesFromDb() {
        ArrayList<Dish> dishes = new ArrayList<>();
        try {
            Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
            Statement stmt = conn.createStatement();
            Statement statement = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String query = "SELECT * FROM dishes";
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                String dishName = rs.getString("dish_name");
                int price = rs.getInt("price");
                int id = rs.getInt("id");
                dishes.add(new Dish(id,dishName,price));
            }
            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return FXCollections.observableArrayList(dishes);
    }

    public void generateDetailedReport(){
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/rkplab1/detailedReport.fxml"));
            Parent root = loader.load();

            Stage newStage = new Stage();
            newStage.setScene(new Scene(root,686,606));

            Stage currentStage = (Stage) generateDetailed.getScene().getWindow();
            currentStage.close();

            newStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public  void getReport(){
        Orderr order = tableView.getSelectionModel().getSelectedItem();
        ReportController controller = new ReportController();
        controller.getSelectedOrder(order.getId(),order.getTotal());
        new Utils().loadNewScene("/org/example/rkplab1/report.fxml",getReport);

    }
    private ObservableList<Order> loadDataFromDatabase() {
        ArrayList<Order> orders = new ArrayList<>();
        try {
            Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
            Statement stmt = conn.createStatement();
            Statement statement = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String query = "SELECT * FROM \"order\";";
            ResultSet rs = stmt.executeQuery(query);
            String query2 = "SELECT f.\"dishName\"\n" +
                    "FROM dishes f INNER JOIN public.\"order\" o on f.id = o.id_food\n" +
                    "WHERE o.id_food = \n";
            ResultSet rs2 = null;
            while (rs.next()) {
                int foodId = rs.getInt("id_food");
                int id = rs.getInt("id");
                Date date = rs.getDate("orderdate");
                int orderAmount = rs.getInt("orderAmount");
                int orderNumber = rs.getInt("orderNumber");
                rs2 = statement.executeQuery(query2 + foodId);
                String dishName = rs2.first() ? rs2.getString("dishName") : null;
                orders.add(new Order(id,dishName,date,orderAmount,orderNumber));
            }
            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return FXCollections.observableArrayList(orders);
    }

    public void deleteButton()  {
        OrderItem selectedItem = myOrder.getSelectionModel().getSelectedItem();
        myOrder.getItems().remove(selectedItem);
        myOrder.refresh();
        selectedOrderItems.remove(selectedItem);
        selectedDishes.removeIf(dish -> dish.getDishName().equals(selectedItem.getDish().getDishName()));
    }

    public void toTheMenu(){
      new Utils().loadNewScene("/org/example/rkplab1/orderMenu.fxml",add);
    }

    public void backToMain() {
        new Utils().loadNewScene("/org/example/rkplab1/hello-view.fxml", backToMain);
    }

    public void backToOrders() {
        new Utils().loadNewScene("/org/example/rkplab1/orders.fxml", backToMain);
    }
}
