package org.example.rkplab1;
import com.opencsv.CSVWriter;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;

public class WordTableExport {
    public static void exportTableToWord(String[][] tableData, String filePath) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filePath, StandardCharsets.UTF_8))) {
            // Начало файла с некоторым форматированием
            writer.println("Таблица заказов");
            writer.println("====================\n");

            // Заголовки таблицы
            writer.printf("%-15s %-10s %-10s %-10s%n", "Название блюда", "Кол-во", "Цена", "Сумма");
            writer.println("----------------------------------------------");

            // Данные таблицы
            double s = 0.0; // Инициализируем сумму
            for (String[] row : tableData) {
                writer.printf("%-15s %-10s %-10s %-10s%n", row[0], row[1], row[2], row[3]);

                // Заменяем запятую на точку и преобразуем в double
                String formattedNumber = row[3].replace(",", ".");
                s += Double.parseDouble(formattedNumber);
            }

                writer.printf("\nИтого                                 %-10s%n", s);
            writer.println("\nСпасибо за ваш заказ!");

            System.out.println("Таблица успешно экспортирована в файл: " + filePath);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
