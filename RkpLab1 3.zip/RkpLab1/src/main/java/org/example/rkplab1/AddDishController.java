package org.example.rkplab1;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.util.StringConverter;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class AddDishController implements Initializable {

    @FXML
    private Button addIngredients;

    public ObservableList<FoodType> types = loadTypesFromDb();

    @FXML
    private ChoiceBox<FoodType> choicebox = new ChoiceBox<>(types);

    @FXML
    private Button startButton;
    @FXML
    private Button  save;

    @FXML
    private Button cancel;

    @FXML
    private TextField description = new TextField();;

    @FXML
    private TextField dishName = new TextField();

    @FXML
    private TextField price = new TextField();;

    @FXML
    private TextField typeName = new TextField();;

    @FXML
    public void cancelButton(){
        new Utils().loadNewScene("/org/example/rkplab1/tableMenu.fxml",cancel);
    }
    @FXML
    public void saveDish(){
        int dishId = 0;
        String sql = "INSERT INTO dishes(dish_name,price,id_food_type,description) VALUES(?,?,?,?)";
        try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
             PreparedStatement statement = connection.prepareStatement(sql)) {
            String dishnameText = dishName.getText();
            String priceText = price.getText();
            int priceValue = 0;
            if (!priceText.isEmpty()) {
                try {
                  priceValue = Integer.parseInt(priceText);
                    
                } catch (NumberFormatException e) {
                    e.printStackTrace(); 
                }
            }
            String typeNameText = choicebox.getValue().getTypeName();
            Statement stmt = connection.createStatement();
            Statement stat = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            stmt.executeUpdate("INSERT INTO food_type(type_name) values( '" + typeNameText + "')");
            String query = "SELECT id from food_type where type_name = '" + typeNameText + "'";
            ResultSet rs = stat.executeQuery(query);
            Integer id = rs.first() ? rs.getInt("id") : null;
            if (id == null) {
                throw new IllegalStateException("ID is null");
            }
            int idValue = id.intValue();
            String descriptionText = description.getText();
            statement.setString(1, dishnameText);
            statement.setInt(2, priceValue);
            statement.setInt(3, idValue);
            statement.setString(4, descriptionText);
            statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }


    }
    @FXML
    public void addIngredients(){
        new Utils().loadNewScene("/org/example/rkplab1/ingredients.fxml",addIngredients);
    }

    private ObservableList<FoodType> loadTypesFromDb() {
        ArrayList<FoodType> types = new ArrayList<>();
        try {
            Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
            Statement stmt = conn.createStatement();
            String query = "SELECT * FROM food_type";
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                String typeName = rs.getString("type_name");
                int id = rs.getInt("id");
                types.add(new FoodType(id,typeName));
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return FXCollections.observableArrayList(types);
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        choicebox.setItems(types);
        choicebox.setConverter(new StringConverter<FoodType>() {
            @Override
            public String toString(FoodType foodType) {
                return foodType == null ? null : foodType.getTypeName();
            }

            @Override
            public FoodType fromString(String string) {
                return types.stream().filter(unit -> unit.getTypeName().equals(string)).findFirst().orElse(null);
            }
        });

        save.setOnAction(event -> {
            String inputData = dishName.getText().trim();
            if (inputData.isEmpty()) {
                showAlert("Нельзя сохранять пустую строку!");
            } else if (isDuplicate(inputData)) {
                showAlert("Такое блюдо уже существует!");
            } else {
                saveDish();
                showAlert("Блюдо сохранено успешно!");
            }
        });

    }

    public static boolean isDuplicate(String value) {
        String query = "SELECT COUNT(*) FROM dishes WHERE dish_name = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, value);
            ResultSet rs = pstmt.executeQuery();
            rs.next();
            return rs.getInt(1) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Уведомление");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
