package org.example.rkplab1;

import javax.persistence.*;


public class Ingredient {

    @Override
    public String toString() {
        return "Ingredient{" +
                "id=" + id +
                ", ingredientName='" + ingredientName + '\'' +
                ", amountInOnePortion=" + amountInOnePortion +
                ", unit=" + unit +
                ", unitName='" + unitName + '\'' +
                '}';
    }

    private int id;

    private String ingredientName;

    private int amountInOnePortion;

    private Unitt unit;

    private String unitName;

    public String getUnitName() {
        return unitName;
    }

    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }

    public Ingredient(int id, String ingredientName, int amountInOnePortion, String unitName) {
        this.id = id;
        this.ingredientName = ingredientName;
        this.amountInOnePortion = amountInOnePortion;
        this.unitName = unitName;
    }

    public Ingredient(int id, String ingredientName,String unitName) {
        this.id = id;
        this.ingredientName = ingredientName;
        this.unitName = unitName;
    }

    public Ingredient(int id, String ingredientName, int amountInOnePortion, Unitt unit) {
        this.id = id;
        this.ingredientName = ingredientName;
        this.amountInOnePortion = amountInOnePortion;
        this.unit = unit;
    }

    public Ingredient() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIngredientName() {
        return ingredientName;
    }

    public void setIngredientName(String ingredientName) {
        this.ingredientName = ingredientName;
    }

    public int getAmountInOnePortion() {
        return amountInOnePortion;
    }

    public void setAmountInOnePortion(int amountInOnePortion) {
        this.amountInOnePortion = amountInOnePortion;
    }

    public Unitt getUnit() {
        return unit;
    }

    public void setUnit(Unitt unit) {
        this.unit = unit;
    }
}
