package org.example.rkplab1;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class Utils {

    public  void loadNewScene(String address, Button button){
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(address));
            Parent root = loader.load();

            Stage newStage = new Stage();
            newStage.setScene(new Scene(root,880,700));

            Stage currentStage = (Stage) button.getScene().getWindow();
            currentStage.close();

            newStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
