package org.example.rkplab1;

import java.util.Objects;

public class  OrderItem {
    private  Dish dish;
    private  Integer orderAmount;

    public OrderItem(Dish dish, Integer orderAmount) {
        this.dish = dish;
        this.orderAmount = orderAmount;
    }

    public OrderItem() {
        this.orderAmount = 0;
    }

    public OrderItem(String dishName, int numberOfDishes, double price, double sum) {

    }

    public Dish getDish() {
        return dish;
    }

    public Integer getOrderAmount() {
        return orderAmount;
    }

    public void setDish(Dish dish) {
        this.dish = dish;
    }

    public void setOrderAmount(Integer orderAmount) {
        this.orderAmount = orderAmount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderItem orderItem = (OrderItem) o;
        return Objects.equals(getDish(), orderItem.getDish());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getDish(), getOrderAmount());
    }


    @Override
    public String toString() {
        return "OrderItem{" +
                "dish=" + dish +
                ", orderAmount=" + orderAmount +
                '}';
    }
}
