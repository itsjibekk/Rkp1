package org.example.rkplab1;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

import java.awt.Desktop;

public class ReportController implements Initializable {

    @FXML
    private Button backToMain;

    @FXML
    private Button delete;

    @FXML
    private Button generateReport;

    @FXML
    private Label labelSum = new Label();

    @FXML
    private Label orderLabel = new Label();

    @FXML
    private TableView<Order> myOrder = new TableView<>();

    @FXML
    private TableColumn<Order, String> number;

    @FXML
    private TableColumn<Order, String> price;

    @FXML
    private TableColumn<Order, String> sum;

    @FXML
    private TableColumn<Order, String> dishName;


    private static int orderId;

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public static double getTotalSum() {
        return totalSum;
    }

    public void setTotalSum(double totalSum) {
        this.totalSum = totalSum;
    }

    private static double totalSum;

    Connection connection; // Implement your connection method

    {
        try {
            connection = getConnection();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void delete() {
        // Get the selected order from the TableView (or other UI components)
        Order order = myOrder.getSelectionModel().getSelectedItem();

        if (order != null) {
            // Step 1: Remove the order from the observable list (if applicable)
            myOrder.getItems().remove(order);

            // Step 2: Delete the order from the database
            String deleteOrderSQL = "DELETE FROM \"order\" WHERE id = ?";

            try (PreparedStatement stmt = connection.prepareStatement(deleteOrderSQL)) {
                stmt.setInt(1, order.getId()); // Set the ID of the order to delete

                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Order deleted from database successfully.");
                } else {
                    System.out.println("Order not found in database.");
                }

                // Recalculate the total sum
                recalculateTotalSum();

                // Update the labelSum with the new total sum
                labelSum.setText(String.format("%.2f", totalSum));

            } catch (SQLException e) {
                System.err.println("Error deleting order: " + e.getMessage());
            }
        } else {
            System.out.println("No order selected to delete.");
        }
    }

    private void recalculateTotalSum() {
        // Recalculate the total sum by summing up the sum of all remaining orders
        totalSum = 0.0;

        for (Order order : myOrder.getItems()) {
            totalSum += order.getSum();
        }

        try (Connection conn = getConnection()) {
            String query = "UPDATE orders " +
                    "SET total = ( " +
                    "    SELECT COALESCE(SUM(o.numberofdishes * d.price), 0) " +
                    "    FROM public.order o " +
                    "    INNER JOIN public.dishes d ON d.id = o.dishid " +
                    "    WHERE o.orderid = ?) " +  // Use ? placeholder for order ID
                    "WHERE id = ?";  // Use ? placeholder for order ID

            try (PreparedStatement prepare = conn.prepareStatement(query)) {
                // Replace the placeholders with the actual order ID
                prepare.setInt(1, orderId);  // Assuming orderId is the ID of the order being updated
                prepare.setInt(2, orderId);  // Assuming orderId is the ID of the order being updated

                // Execute the update
                int rowsAffected = prepare.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Order total updated successfully.");
                } else {
                    System.out.println("Order not found for ID: " + orderId);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Update the labelSum with the new total sum
        labelSum.setText(String.valueOf(totalSum));
    }



    // Dummy method for database connection
    private Connection getConnection() throws SQLException {
        // Implement connection logic (e.g., using DriverManager or a DataSource)
        return DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
    }

    public void toTheMenu(){
        new Utils().loadNewScene("/org/example/rkplab1/orders.fxml",backToMain);
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        myOrder();
        dishName.setCellValueFactory(new PropertyValueFactory<>("dishName"));
        number.setCellValueFactory(new PropertyValueFactory<>("orderNumber"));
        price.setCellValueFactory(new PropertyValueFactory<>("price"));
        sum.setCellValueFactory(new PropertyValueFactory<>("sum"));

        if (labelSum != null && orderLabel != null) {
            labelSum.setText(String.valueOf(totalSum));
            orderLabel.setText(String.valueOf(orderId));
        }

    }

    public void getSelectedOrder(int orderId,double totalSum){
        this.orderId = orderId;
        this.totalSum = totalSum;

    }

    public String[][] myOrder(){
        ObservableList<Order> orderItems = FXCollections.observableArrayList();

        String getMyOrder = "SELECT id, dishid, numberofdishes FROM \"order\" WHERE orderid = ?";
        String getDishDetails = "SELECT dish_name, price FROM dishes WHERE id = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
             PreparedStatement orderStmt = conn.prepareStatement(getMyOrder)) {

            // Set the orderId parameter
            orderStmt.setInt(1, orderId);
            ResultSet orderRs = orderStmt.executeQuery();

            while (orderRs.next()) {
                int dishId = orderRs.getInt("dishid");
                int numberOfDishes = orderRs.getInt("numberofdishes");
                int orderId = orderRs.getInt("id");

                try (PreparedStatement dishStmt = conn.prepareStatement(getDishDetails)) {
                    dishStmt.setInt(1, dishId);
                    ResultSet dishRs = dishStmt.executeQuery();

                    if (dishRs.next()) {
                        String dishName = dishRs.getString("dish_name");
                        double price = dishRs.getDouble("price");
                        double sum = price * numberOfDishes;

                        orderItems.add(new Order(orderId,dishName, numberOfDishes, price, sum));

                    }
                }
            }
            for (Order order : orderItems) {
                System.out.println(order.toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }



        myOrder.setItems(orderItems);
        return convertTo2DArray(orderItems);
    }

    public void generateFile() {
        String filePath = "order_report.doc";

        // Generate the Word file
        WordTableExport.exportTableToWord(myOrder(), filePath);

        // Display a success alert
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("File Created");
        alert.setHeaderText(null);
        alert.setContentText("The Word file has been created successfully!");
        alert.showAndWait();

        // Automatically open the Word file
        File file = new File(filePath);
        if (file.exists()) {
            try {
                Desktop.getDesktop().open(file);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setTitle("File Not Found");
            errorAlert.setHeaderText(null);
            errorAlert.setContentText("Failed to open the Word file. File not found.");
            errorAlert.showAndWait();
        }
    }
    public static String[][] convertTo2DArray(ObservableList<Order> orderItems) {
        // Initialize the String[][] array with the size of the ObservableList
        String[][] tableData = new String[orderItems.size()][];

        // Iterate through the ObservableList and populate the String[][]
        for (int i = 0; i < orderItems.size(); i++) {
            Order order = orderItems.get(i);
            tableData[i] = new String[]{
                    order.getDishName(),
                    String.valueOf(order.getOrderNumber()),
                    String.format("%.2f", order.getPrice()),
                    String.format("%.2f", order.getSum())
            };
        }
        return tableData;
    }
}
