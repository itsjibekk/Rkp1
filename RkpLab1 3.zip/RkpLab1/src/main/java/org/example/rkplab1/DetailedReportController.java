package org.example.rkplab1;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.beans.property.*;
import javafx.stage.FileChooser;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.*;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import com.opencsv.CSVWriter;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.sql.Date;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

public class DetailedReportController implements Initializable {

    @FXML
    private TableView<OrderReport> tableView;

    @FXML
    private TableView<OrderType> types;
    @FXML
    private DatePicker from;
    @FXML
    private DatePicker to;
    @FXML
    private Button generateReport;
    @FXML
    private Button back;

    private ObservableList<OrderReport> orderData = FXCollections.observableArrayList();
    private ObservableList<OrderType> typeData = FXCollections.observableArrayList();

    private static final String URL = "jdbc:postgresql://localhost:5432/menus_db";
    private static final String USER = "postgres";
    private static final String PASSWORD = "postgres";

    @FXML
    private void back() {
        new Utils().loadNewScene("/org/example/rkplab1/orders.fxml", back);
    }

    @FXML
    private void generateReport() {
        LocalDate startDate = from.getValue();
        LocalDate endDate = to.getValue();

        if (startDate == null || endDate == null) {
            showAlert("Ошибка", "Выберите начальную и конечную дату!");
            return;
        }

        orderData.clear();
        typeData.clear();

        String query = "SELECT i.name AS ingredient_name, " +
                "SUM(fc.amountinoneportion * o.numberofdishes) AS total_quantity, " +
                "u.name AS unit_name, " +
                "i.price_per_unit AS price_per_unit, " +
                "SUM(fc.amountinoneportion * o.numberofdishes * i.price_per_unit) AS total_cost " +
                "FROM orders ord " +
                "JOIN \"order\" o ON ord.id = o.orderid " +
                "JOIN dishes d ON o.dishid = d.id " +
                "JOIN foodcalculations fc ON d.id = fc.id_dishes " +
                "JOIN ingredients i ON fc.id_ingredients = i.id " +
                "JOIN units u ON i.id_units = u.id " +
                "WHERE ord.orderdate BETWEEN ? AND ? " +
                "GROUP BY i.name, u.name, i.price_per_unit " +
                "ORDER BY i.name";

        String getTypes = "SELECT\n" +
                "    ft.type_name,\n" +
                "    d.dish_name,\n" +
                "    SUM(o.numberofdishes) AS total\n" +
                "FROM \"order\" o\n" +
                "         JOIN dishes d ON o.dishid = d.id\n " +
                "         JOIN food_type ft ON d.id_food_type = ft.id\n " +
                "         JOIN  orders ord ON ord.id = o.orderid " +
                "WHERE ord.orderdate BETWEEN ? AND ? " +
                "GROUP BY ft.type_name, d.dish_name;";

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement statement = connection.prepareStatement(query);
             PreparedStatement state = connection.prepareStatement(getTypes)) {

            statement.setDate(1, Date.valueOf(startDate));
            statement.setDate(2, Date.valueOf(endDate));

            state.setDate(1, Date.valueOf(startDate));
            state.setDate(2, Date.valueOf(endDate));


            ResultSet resultSet = statement.executeQuery();
            ResultSet result = state.executeQuery();
            while (resultSet.next()) {
                orderData.add(new OrderReport(
                        resultSet.getString("ingredient_name"),
                        resultSet.getDouble("total_quantity"),
                        resultSet.getString("unit_name"),
                        resultSet.getDouble("price_per_unit"),
                        resultSet.getDouble("total_cost")
                ));
            }



            while(result.next()){
                typeData.add(new OrderType(
                        result.getString("type_name"),
                        result.getDouble("total"),
                        result.getString("dish_name")
                ));
            }
            tableView.setItems(orderData);
            types.setItems(typeData);

        } catch (SQLException e) {
            showAlert("Ошибка БД", "Не удалось получить данные: " + e.getMessage());
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }



    public void exportToExcel() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Excel файлы", "*.xlsx"));
        fileChooser.setInitialFileName("report.xlsx");

        File file = fileChooser.showSaveDialog(null);
        if (file == null) return;

        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            XSSFSheet sheet = workbook.createSheet("Отчет по заказам");
            int currentRow = 0;

            // Стили
            XSSFCellStyle headerStyle = workbook.createCellStyle();
            XSSFFont headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerFont.setFontHeightInPoints((short) 14);
            headerStyle.setFont(headerFont);

            XSSFCellStyle categoryStyle = workbook.createCellStyle();
            XSSFFont categoryFont = workbook.createFont();
            categoryFont.setBold(true);
            categoryFont.setColor(IndexedColors.DARK_BLUE.getIndex());
            categoryStyle.setFont(categoryFont);

            XSSFCellStyle tableHeaderStyle = workbook.createCellStyle();
            tableHeaderStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            tableHeaderStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            tableHeaderStyle.setBorderBottom(BorderStyle.THIN);

            // Заголовок отчета
            Row titleRow = sheet.createRow(currentRow++);
            Cell titleCell = titleRow.createCell(0);
            titleCell.setCellValue("Отчет по заказам");
            titleCell.setCellStyle(headerStyle);

            // Дата
            Row dateRow = sheet.createRow(currentRow++);
            dateRow.createCell(0).setCellValue("Дата от: " + from.getValue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
            dateRow.createCell(1).setCellValue("Дата до: " + to.getValue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
            currentRow++; // Пустая строка

            // Группировка блюд по типам
            Map<String, List<OrderType>> groupedDishes = typeData.stream()
                    .collect(Collectors.groupingBy(
                            OrderType::getTypeName,
                            LinkedHashMap::new,
                            Collectors.toList()
                    ));

            // Вывод категорий и блюд
            for (Map.Entry<String, List<OrderType>> entry : groupedDishes.entrySet()) {
                Row categoryRow = sheet.createRow(currentRow++);
                Cell categoryCell = categoryRow.createCell(0);
                categoryCell.setCellValue("[" + entry.getKey() + "]");
                categoryCell.setCellStyle(categoryStyle);

                for (OrderType dish : entry.getValue()) {
                    Row dishRow = sheet.createRow(currentRow++);
                    dishRow.createCell(1).setCellValue(dish.getDishName() + " (" + dish.getTotalQuantity() + " шт)");
                }
                currentRow++; // Пустая строка
            }

            // Таблица ингредиентов
            String[] columns = {"Название ингредиента", "Единица измерения", "Цена за ед. изм.","Количество", "Общая стоимость"};
            Row tableHeaderRow = sheet.createRow(currentRow++);
            for (int i = 0; i < columns.length; i++) {
                Cell cell = tableHeaderRow.createCell(i);
                cell.setCellValue(columns[i]);
                cell.setCellStyle(tableHeaderStyle);
            }

            // Данные ингредиентов
            DecimalFormat df = new DecimalFormat("#,##0.00", new DecimalFormatSymbols(Locale.forLanguageTag("ru")));
            for (OrderReport ingredient : orderData) {
                Row dataRow = sheet.createRow(currentRow++);
                dataRow.createCell(0).setCellValue(ingredient.getIngredientName());
                dataRow.createCell(1).setCellValue(ingredient.getUnitName().replace(".", ","));
                dataRow.createCell(2).setCellValue(ingredient.getPricePerUnit()); // напрямую
                dataRow.createCell(3).setCellValue(ingredient.getTotalQuantity());
                dataRow.createCell(4).setCellValue(ingredient.getTotalCost());

            }

            // Авто-размер колонок
            for (int i = 0; i < columns.length; i++) {
                sheet.autoSizeColumn(i);
            }

            // Сохранение файла
            try (FileOutputStream fos = new FileOutputStream(file)) {
                workbook.write(fos);
                showAlert("Успех", "Excel-отчет создан!");
            }
        } catch (IOException e) {
            showAlert("Ошибка", "Ошибка: " + e.getMessage());
        }
    }
    public void exportToCSV() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV файлы", "*.csv"));
        fileChooser.setInitialFileName("report.csv");

        File file = fileChooser.showSaveDialog(null);
        if (file == null) return;

        // Настройка форматирования чисел для русской локали
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.forLanguageTag("ru"));
        symbols.setDecimalSeparator(',');
        DecimalFormat df = new DecimalFormat("#0.00", symbols);

        try (CSVWriter writer = new CSVWriter(new FileWriter(file, StandardCharsets.UTF_8))) {
            // 1. Заголовок отчета с датой
            String currentDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
            writer.writeNext(new String[]{"# Отчет по заказам"});
            writer.writeNext(new String[]{"Дата: " + currentDate});
            writer.writeNext(new String[]{}); // Пустая строка

            // 2. Группировка блюд по типам
            Map<String, List<OrderType>> groupedDishes = typeData.stream()
                    .collect(Collectors.groupingBy(
                            OrderType::getTypeName,
                            LinkedHashMap::new,
                            Collectors.toList()
                    ));

            // 3. Вывод категорий и блюд
            for (Map.Entry<String, List<OrderType>> entry : groupedDishes.entrySet()) {
                String category = entry.getKey();
                List<OrderType> dishes = entry.getValue();

                // Заголовок категории
                writer.writeNext(new String[]{"[" + category + "]"});

                // Список блюд
                for (OrderType dish : dishes) {
                    writer.writeNext(new String[]{dish.getDishName() + " (" + dish.getTotalQuantity() + " шт)"});
                }
                writer.writeNext(new String[]{}); // Пустая строка после категории
            }

            // 4. Таблица ингредиентов (имитация таблицы через разделители)
            writer.writeNext(new String[]{"| Название ингредиента | Единица измерения | Цена за ед. изм. | Общая стоимость |"});
            writer.writeNext(new String[]{"|------------------------------|---------------------------|-----------------------|------------------------|"});

            for (OrderReport ingredient : orderData) {
                String row = String.format(
                        "| %-20s | %-17s | %-17s | %-16s |",
                        ingredient.getIngredientName(),
                        ingredient.getUnitName().replace(".", ","),
                        df.format(ingredient.getPricePerUnit()),
                        df.format(ingredient.getTotalCost())
                );
                writer.writeNext(new String[]{
                        ingredient.getIngredientName(),
                        ingredient.getUnitName().replace(".", ","),
                        df.format(ingredient.getPricePerUnit()),
                        df.format(ingredient.getTotalCost())
                });
            }
            showAlert("Успех", "Отчет успешно экспортирован!");
        } catch (IOException e) {
            showAlert("Ошибка", "Ошибка при экспорте: " + e.getMessage());
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        TableColumn<OrderReport, String> ingredientColumn = new TableColumn<>("Ингредиент");
        TableColumn<OrderReport, Double> quantityColumn = new TableColumn<>("Общее количество");
        TableColumn<OrderReport, String> unitColumn = new TableColumn<>("Ед. измерения");
        TableColumn<OrderReport, Double> priceColumn = new TableColumn<>("Цена за ед.");
        TableColumn<OrderReport, Double> totalCostColumn = new TableColumn<>("Общая стоимость");

        ingredientColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getIngredientName()));
        quantityColumn.setCellValueFactory(cellData -> new SimpleDoubleProperty(cellData.getValue().getTotalQuantity()).asObject());
        unitColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getUnitName()));
        priceColumn.setCellValueFactory(cellData -> new SimpleDoubleProperty(cellData.getValue().getPricePerUnit()).asObject());
        totalCostColumn.setCellValueFactory(cellData -> new SimpleDoubleProperty(cellData.getValue().getTotalCost()).asObject());

        tableView.getColumns().addAll(ingredientColumn, quantityColumn, unitColumn, priceColumn, totalCostColumn);



        TableColumn<OrderType, String> typeColumn = new TableColumn<>("Тип");
        TableColumn<OrderType, Double> totalColumn = new TableColumn<>("Общее количество");
        TableColumn<OrderType, String> dishColumn = new TableColumn<>("Блюдо");

        typeColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getTypeName()));
        totalColumn.setCellValueFactory(cellData -> new SimpleDoubleProperty(cellData.getValue().getTotalQuantity()).asObject());
        dishColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getDishName()));

        types.getColumns().addAll(typeColumn, totalColumn, dishColumn);

        generateReport.setOnAction(e -> generateReport());
    }

    public static class OrderReport {
        private final String ingredientName;
        private final double totalQuantity;
        private final String unitName;
        private final double pricePerUnit;
        private final double totalCost;

        public OrderReport(String ingredientName, double totalQuantity, String unitName, double pricePerUnit, double totalCost) {
            this.ingredientName = ingredientName;
            this.totalQuantity = totalQuantity;
            this.unitName = unitName;
            this.pricePerUnit = pricePerUnit;
            this.totalCost = totalCost;
        }

        public String getIngredientName() { return ingredientName; }
        public double getTotalQuantity() { return totalQuantity; }
        public String getUnitName() { return unitName; }
        public double getPricePerUnit() { return pricePerUnit; }
        public double getTotalCost() { return totalCost; }
    }
    public static class OrderType {
        private final String typeName;
        private final double totalQuantity;
        private final String dishName;

        public OrderType(String typeName, double totalQuantity, String dishName) {
            this.typeName = typeName;
            this.totalQuantity = totalQuantity;
            this.dishName = dishName;
        }


        public String getTypeName() {
            return typeName;
        }

        public double getTotalQuantity() {
            return totalQuantity;
        }

        public String getDishName() {
            return dishName;
        }
    }
}
