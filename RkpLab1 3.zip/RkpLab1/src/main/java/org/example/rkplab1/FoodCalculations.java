package org.example.rkplab1;

import javax.persistence.*;

@Entity
@Table
public class FoodCalculations {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "dish_id")
    private Dish dish;

    @Column(name = "ingredient_id")
    private Ingredient ingredient;

    @Column(name = "amount_in_one_portion")
    private double amountInOnePortion;
}
