package org.example.rkplab1;

import javax.persistence.*;

@Entity
@Table
public class Unitt {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "unit_name")
    private String unitName;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUnitName() {
        return unitName;
    }

    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }

    @Override
    public String toString() {
        return "Unitt{" +
                "id=" + id +
                ", unitName='" + unitName + '\'' +
                '}';
    }

    public Unitt() {
    }

    public Unitt(int id, String unitName) {
        this.id = id;
        this.unitName = unitName;
    }
}
