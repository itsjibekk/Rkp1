package org.example.rkplab1;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;


import java.io.*;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class CookBookStart implements Initializable {

    private static int count = 0;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button startButton;

    @FXML
    private Button orders;

    @FXML
    private Button add;

    @FXML
    private Button ingredients;

    @FXML
    private Button backToMain;

    @FXML
    private TextField unitName;


    @FXML
    private Button addToChart;

    @FXML
    private Button getReport;

    @FXML
    private Button delete;

    @FXML
    private Button units;

    @FXML
    private Button receipts;

    @FXML
    private Button saveUnit = new Button();

    @FXML
    private Button backToTheMenu;

    @FXML
    private Button update;

    @FXML
    private Button types;

    @FXML
    private TableView<Dish> tableView = new TableView<Dish>();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        TableColumn id = new TableColumn("ID");
        TableColumn dishName = new TableColumn("Наименование блюд");
        TableColumn price = new TableColumn("Цена");
        TableColumn description = new TableColumn("Описание");
        TableColumn<Dish,String> foodType = new TableColumn<Dish,String>("Тип блюда");

        tableView.getColumns().addAll(id,dishName,price,description,foodType);

        final ObservableList<Dish> data = loadDataFromDatabase();

        id.setCellValueFactory(new PropertyValueFactory<Dish, Integer>("id"));
        price.setCellValueFactory(new PropertyValueFactory<Dish, Integer>("price"));
        dishName.setCellValueFactory(new PropertyValueFactory<Dish, String>("dishName"));
        description.setCellValueFactory(new PropertyValueFactory<Dish, String>("description"));
        foodType.setCellValueFactory(new PropertyValueFactory<>("typeName"));

        tableView.setItems(data);


        saveUnit.setOnAction(event -> {
            String inputData = unitName.getText().trim();
            if (inputData.isEmpty()) {
                showAlert("Нельзя сохранять пустую строку!");
            } else if (isDuplicate(inputData)) {
                showAlert("Такая единица измерения уже существует!");
            } else {
                setSaveUnit();
                showAlert("Единица измерения сохранена успешно!");
            }
        });
    }

    public static boolean isDuplicate(String value) {
        String query = "SELECT COUNT(*) FROM units WHERE name = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, value);
            ResultSet rs = pstmt.executeQuery();
            rs.next();
            return rs.getInt(1) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Уведомление");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public ObservableList<Dish> loadDataFromDatabase() {
        ArrayList<Dish> dishes = new ArrayList<>();
        try {
            Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
            Statement stmt = conn.createStatement();
            Statement statement = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String query = "SELECT * FROM dishes";
            ResultSet rs = stmt.executeQuery(query);
            String query2 = "SELECT f.type_name\n" +
                    "FROM food_type f\n" +
                    "         INNER JOIN dishes d ON f.id = d.id_food_type\n" +
                    "WHERE d.id_food_type = ";
            ResultSet rs2 = null;
            while (rs.next()) {
                String dishName = rs.getString("dish_name");
                int price = rs.getInt("price");
                int id = rs.getInt("id");
                String description = rs.getString("description");
                int typeId = rs.getInt("id_food_type");
                rs2 = statement.executeQuery(query2 + typeId);
                String typeName = rs2.first() ? rs2.getString("type_name") : null;
                dishes.add(new Dish(id,dishName,price,typeName,description));
            }

            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return FXCollections.observableArrayList(dishes);
    }

    public void types(){
        new Utils().loadNewScene("/org/example/rkplab1/typesTable.fxml",types);
    }

    public void setReceipts(){
        new Utils().loadNewScene("/org/example/rkplab1/receipts.fxml",receipts);
    }
    public void generateReport() {
        List<Dish> myDishes = chart();

        for(Dish dish : myDishes){
            System.out.println(dish.toString());
        }

        Set<DishDao> myDishDaos = new HashSet<>();
        DishDao dishDao = null;
        for(Dish dish : myDishes){
            Connection conn = null;
            dishDao = new DishDao();
            long count = countDuplicates(myDishes, dish);

            String findIngredientsId = "SELECT id_ingredients" +
                          " FROM foodcalculations" +
                           " WHERE id_dishes = ?";

            String findIngredients = "SELECT * FROM ingredients WHERE id = ?";
            String findUnitById = "SELECT * FROM units WHERE id = ?";
            String findAmountInOnePortionByIngId = "SELECT amountInOnePortion FROM foodcalculations WHERE id_ingredients = ?";
            List<Ingredient> listIngredients = new ArrayList<>();
            try {
                conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
                PreparedStatement stmt = conn.prepareStatement(findIngredientsId);
                PreparedStatement stmt2 = conn.prepareStatement(findIngredients);
                PreparedStatement statement = conn.prepareStatement(findUnitById);

                PreparedStatement statement1 = conn.prepareStatement(findAmountInOnePortionByIngId);
                stmt.setLong(1,dish.getId());
                ResultSet rs = stmt.executeQuery(); // исправлено на executeQuery()
                List<Integer> listOfInteger = new ArrayList<>();
                while(rs.next()){
                    listOfInteger.add(rs.getInt("id_ingredients"));
                }
                
                for(Integer id : listOfInteger){
                    Ingredient ingredient = new Ingredient();
                    stmt2.setLong(1,id);
                    rs = stmt2.executeQuery();
                    while(rs.next()){
                        ingredient.setId(rs.getInt("id"));
                        ingredient.setIngredientName(rs.getString("name"));
                        int unitId = rs.getInt("id_units");
                        statement.setLong(1,unitId);
                        ResultSet rs2 = statement.executeQuery();
                        while(rs2.next()){
                            ingredient.setUnitName(rs2.getString("name"));
                        }
                        statement1.setLong(1,id);
                        ResultSet rs3 = statement1.executeQuery();
                        while(rs3.next()){
                            ingredient.setAmountInOnePortion(rs3.getInt("amountinoneportion"));
                        }
                    }

                    listIngredients.add(ingredient);

                }

                dishDao.setDishName(dish.getDishName());
                dishDao.setIngredients(listIngredients);
                dishDao.setPrice(dish.getPrice());
                dishDao.setNumberOfPortions((int) count);
                dishDao.setSum(count * dish.getPrice());
                myDishDaos.add(dishDao);

            } catch (SQLException e) {
                throw new RuntimeException(e);
            }

        }


       myDishDaos=  myDishDaos.stream().distinct().collect(Collectors.toSet());
        for(DishDao dish : myDishDaos){
            System.out.println(dish.toString());
        }

        try {
            FileWriter writer = new FileWriter("objects.txt");
            for (DishDao dao : myDishDaos) {
                writer.write(dao.toString());
                writer.write(System.lineSeparator()); // Add a new line after each object
            }
            writer.close();
            System.out.println("Objects successfully written to file.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void calculation(){
        new Utils().loadNewScene("/org/example/rkplab1/calculation.fxml",orders);
    }


    public void orders(){
        new Utils().loadNewScene("/org/example/rkplab1/orders.fxml",orders);
    }

    public static <T> int countDuplicates(List<T> list, T item) {
        return (int) list.stream().filter(element -> element.equals(item)).count();
    }
    List<Dish> selectedItems = new ArrayList<>();

    public List<Dish> chart() {
        Dish dish = tableView.getSelectionModel().getSelectedItem();
        selectedItems.add(dish);
        String insertOrder = "INSERT INTO \"order\"(id_food, orderdate, orderamount) VALUES (?, ?, ?)";

        try {
            Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
            PreparedStatement statement = connection.prepareStatement(insertOrder);
            statement.setInt(1,dish.getId());
            statement.setDate(2,java.sql.Date.valueOf(LocalDate.now()));
            statement.setInt(3,countDuplicates(selectedItems,dish));
            statement.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return selectedItems;
    }



    public void deleteButton()  {
        Dish selectedItem = tableView.getSelectionModel().getSelectedItem();
        tableView.getItems().remove(selectedItem);
        tableView.refresh();
        Connection conn = null;
        try {
            String query = "DELETE FROM dishes where id = ?";
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setLong(1,selectedItem.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


    }

    public void units(){
        new Utils().loadNewScene("/org/example/rkplab1/unitsTable.fxml",units);
    }
    public void backToMain(){
        new Utils().loadNewScene("/org/example/rkplab1/hello-view.fxml",backToMain);
    }

    public void backToMenu(){
        new Utils().loadNewScene("/org/example/rkplab1/unitsTable.fxml",backToTheMenu);
    }

    public  void setIngredients(){
        new Utils().loadNewScene("/org/example/rkplab1/ingredients.fxml",ingredients);
    }

    public void setSaveUnit(){
        String unit = unitName.getText();
        String query = "INSERT INTO units(name) values(?)";
        try {
            Connection con  = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
            PreparedStatement prStat = con.prepareStatement(query);
            prStat.setString(1,unit);
            prStat.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    @FXML
    public void showOtherFXML() {
        new Utils().loadNewScene("/org/example/rkplab1/tableMenu.fxml",startButton);
    }

    @FXML
    public void addButton() {
        new Utils().loadNewScene("/org/example/rkplab1/add.fxml",add);
    }

}
