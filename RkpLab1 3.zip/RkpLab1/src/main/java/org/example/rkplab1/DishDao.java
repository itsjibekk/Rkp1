package org.example.rkplab1;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

public class DishDao implements Serializable {

    @Override
    public String toString() {
        return "\n\nDishDao{" +
                "\ndishName='" + dishName + '\'' +
                ",\ningredients=" + ingredients +
                ",\nnumberOfPortions=" + numberOfPortions +
                ",\nprice=" + price +
                ",\nsum=" + sum + " " +
                '}';
    }

    private String dishName;

    private List<Ingredient> ingredients;

    private int numberOfPortions;

    private double price;


    private double sum;

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getSum() {
        return sum;
    }

    public void setSum(double sum) {
        this.sum = sum;
    }

    public DishDao() {
    }

    public DishDao(String dishName, List<Ingredient> ingredients, int numberOfPortions, double price, double sum) {
        this.dishName = dishName;
        this.ingredients = ingredients;
        this.numberOfPortions = numberOfPortions;
        this.price = price;
        this.sum = sum;
    }

    public String getDishName() {
        return dishName;
    }

    public void setDishName(String dishName) {
        this.dishName = dishName;
    }

    public List<Ingredient> getIngredients() {
        return ingredients;
    }

    public void setIngredients(List<Ingredient> ingredients) {
        this.ingredients = ingredients;
    }

    public int getNumberOfPortions() {
        return numberOfPortions;
    }

    public void setNumberOfPortions(int numberOfPortions) {
        this.numberOfPortions = numberOfPortions;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DishDao dishDao = (DishDao) o;
        return numberOfPortions == dishDao.numberOfPortions &&
                Double.compare(dishDao.price, price) == 0 &&
                Double.compare(dishDao.sum, sum) == 0 &&
                Objects.equals(dishName, dishDao.dishName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(dishName, numberOfPortions, price, sum);
    }

}
