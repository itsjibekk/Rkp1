package org.example.rkplab1;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.StringConverter;

import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class UpdateRecipeController implements Initializable {

    private static String dishName;

    public void setDishName(String dishName) {
            this.dishName = dishName;
    }

    public String getDishName() {
        return this.dishName;
    }

    @FXML
    private Button addIng;

    @FXML
    private TextField amountText;

    @FXML
    private Button backToRecipeTable;

    @FXML
    private Button deleteIng;

    @FXML
    private ChoiceBox<Dish> dishNameChoice = new ChoiceBox<>();

    @FXML
    private TableView<Ingredient> myIngs;

    @FXML
    private Button save;
    public  ObservableList<Ingredient> ingredients = loadIngsFromDb();

    public ObservableList<Dish> dishes = loadDishesFromDb();

    @FXML
    private ChoiceBox<Ingredient> ingChoice = new ChoiceBox<>(ingredients);

    public Integer getDishId() {
        Connection conn = null;
        String findByName = "SELECT id FROM dishes WHERE dish_name = ?";
        Integer id = null;

        try {
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
            PreparedStatement ps1 = conn.prepareStatement(findByName);

            ps1.setString(1, getDishName());
            ResultSet rs = ps1.executeQuery();
            while(rs.next()){
                id = rs.getInt("id");
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return id;
    }
    void addIngToTheDishInDb(Ingredient ing) {
        Connection conn = null;
        String insertIntoFoodCalc = "INSERT INTO foodcalculations(id_dishes, id_ingredients, amountinoneportion)" +
                " VALUES (?, ?, ?)";
        String findIngIdByName = "SELECT id FROM ingredients WHERE name = ?";

        try {
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
            PreparedStatement ps1 = conn.prepareStatement(findIngIdByName);
            PreparedStatement ps = conn.prepareStatement(insertIntoFoodCalc);

            ps1.setString(1, ing.getIngredientName());
            ResultSet rs = ps1.executeQuery();

            if (rs.next()) {  // Move the cursor to the first row
                int ingredientId = rs.getInt("id");

                ps.setInt(1, dishNameChoice.getValue().getId());
                ps.setInt(2, ingredientId);
                ps.setInt(3, ing.getAmountInOnePortion());

                int rowsAffected = ps.executeUpdate();  // Use executeUpdate() for INSERT

                if (rowsAffected > 0) {
                    System.out.println("Data has been successfully saved to the database.");
                } else {
                    System.out.println("Data was not saved to the database.");
                }
            } else {
                System.out.println("Ingredient not found in the database.");
            }
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
       myIngs.refresh();
    }

    @FXML
    void addIngredient() {
        try {
            String ingredientName = ingChoice.getValue().getIngredientName();
            Unitt unit = ingChoice.getValue().getUnit();
            int newAmount = Integer.parseInt(amountText.getText());

            // Check if the ingredient already exists in the TableView
            for (Ingredient existingIng : myIngs.getItems()) {
                if (existingIng.getIngredientName().equals(ingredientName)) {
                    // If found, update the amount
                    existingIng.setAmountInOnePortion(existingIng.getAmountInOnePortion() + newAmount);

                    // Update the ingredient in the database
                    updateIngredientAmountInDb(existingIng);

                    // Refresh TableView
                    myIngs.refresh();

                    // Clear input fields
                    amountText.clear();
                    ingChoice.setValue(null);
                    return; // Exit method after updating existing ingredient
                }
            }

            // If not found, add a new ingredient
            Ingredient ing = new Ingredient();
            ing.setIngredientName(ingredientName);
            ing.setUnit(unit);
            ing.setAmountInOnePortion(newAmount);

            addIngToTheDishInDb(ing); // Save new ingredient in DB

            // Manually add the new ingredient to the TableView
            myIngs.getItems().add(ing);

            // Clear input fields
            amountText.clear();
            ingChoice.setValue(null);

        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Failed to Add Ingredient");
            alert.setContentText("Please ensure all fields are filled correctly.");
            alert.showAndWait();
        }
    }

    // Update the ingredient's amount in the database
    private void updateIngredientAmountInDb(Ingredient ing) {
        String query = "UPDATE public.foodcalculations SET amountinoneportion = ? WHERE id_ingredients = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, ing.getAmountInOnePortion());
            stmt.setInt(2, ing.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }





    @FXML
    void saveIngsToTheRecipe(ActionEvent event) {

    }

    @FXML
    void setBackToRecipeTable(){
        new Utils().loadNewScene("/org/example/rkplab1/receipts.fxml",backToRecipeTable);
    }

    private ObservableList<Ingredient> loadIngsFromDb() {
        List<Ingredient> myIngs = new ArrayList<>();
        Connection conn = null;

        String query = "SELECT * FROM ingredients;";
        String query2 = "SELECT * FROM units WHERE id = ?";
        try {
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
            Statement stmt = conn.createStatement();
            PreparedStatement ps = conn.prepareStatement(query2);

            ResultSet resultSet = stmt.executeQuery(query);
            while (resultSet.next()) {
                Ingredient ing = new Ingredient();
                ing.setId(resultSet.getInt("id"));
                ing.setIngredientName(resultSet.getString("name"));

                ps.setInt(1, resultSet.getInt("id_units"));
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    Unitt unitt = new Unitt(rs.getInt("id"), rs.getString("name"));
                    ing.setUnit(unitt);
                }
                rs.close();

                myIngs.add(ing);
            }

            resultSet.close();
            stmt.close();
            ps.close();
            conn.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return FXCollections.observableArrayList(myIngs);

    }

    private ObservableList<Ingredient> loadIngsOfTheDish() {
        List<Ingredient> myIngs = new ArrayList<>();
        Connection conn = null;

        String query = "SELECT * FROM foodcalculations where id_dishes = ?";

        try {
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
            Statement stmt = conn.createStatement();
            PreparedStatement ps = conn.prepareStatement(query);

            ps.setInt(1, dishNameChoice.getValue().getId());
            ResultSet resultSet = stmt.executeQuery(query);
            while (resultSet.next()) {
                Ingredient ing = new Ingredient();
                ing.setId(resultSet.getInt("id"));
                ing.setIngredientName(resultSet.getString("name"));
                ps.setInt(1, resultSet.getInt("id_units"));
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    Unitt unitt = new Unitt(rs.getInt("id"), rs.getString("name"));
                    ing.setUnit(unitt);
                }
                rs.close();
                myIngs.add(ing);
            }

            resultSet.close();
            stmt.close();
            ps.close();
            conn.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return FXCollections.observableArrayList(myIngs);

    }

    private ObservableList<Dish> loadDishesFromDb() {
        List<Dish> myDishes = new ArrayList<>();
        Connection conn = null;

        String query = "SELECT * FROM dishes;";
        String query2 = "SELECT * FROM food_type WHERE id = ?";
        try {
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
            Statement stmt = conn.createStatement();
            PreparedStatement ps = conn.prepareStatement(query2);

            ResultSet resultSet = stmt.executeQuery(query);
            while (resultSet.next()) {
                Dish dish = new Dish();
                dish.setId(resultSet.getInt("id"));
                dish.setDishName(resultSet.getString("dish_name"));
                dish.setDescription(resultSet.getString("description"));
                dish.setPrice(resultSet.getInt("price"));

                ps.setInt(1, resultSet.getInt("id_food_type"));
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    FoodType foodType = new FoodType(rs.getInt("id"), rs.getString("type_name"));
                    dish.setFoodType(foodType);
                }
                rs.close();

                myDishes.add(dish);
            }

            resultSet.close();
            stmt.close();
            ps.close();
            conn.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return FXCollections.observableArrayList(myDishes);
    }

    public void deleteIng(){
        Ingredient selectedIngredient = myIngs.getSelectionModel().getSelectedItem();
        if (selectedIngredient != null) {
            // Remove from TableView
            myIngs.getItems().remove(selectedIngredient);
            // Remove from database
            deleteIngredientFromDatabase(selectedIngredient);
        } else {
            // Optionally, show an alert if no ingredient is selected
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("No Selection");
            alert.setHeaderText("No Ingredient Selected");
            alert.setContentText("Please select an ingredient to delete.");
            alert.showAndWait();
        }
    }

    private void deleteIngredientFromDatabase(Ingredient ingredient) {
        String deleteQuery = "DELETE FROM foodcalculations WHERE id_dishes = ? AND id_ingredients = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
             PreparedStatement ps = conn.prepareStatement(deleteQuery)) {

            ps.setInt(1, dishNameChoice.getValue().getId());
            ps.setInt(2, ingredient.getId());
            int rowsAffected = ps.executeUpdate();


            if (rowsAffected > 0) {
                System.out.println("Ingredient successfully deleted from the database.");
            } else {
                System.out.println("Ingredient not found in the database." + dishNameChoice.getValue().toString() + "  " + ingredient.getIngredientName());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void saveIngsToTheRecipe(){
        String str = "INSERT INTO foodcalculations(id_dishes,id_ingredients,amountinoneportion) VALUES (?,?,?);";
        Connection conn = null;

        try{
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db","postgres", "postgres");
            PreparedStatement ps = conn.prepareStatement(str);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                FoodCalculations fc = new FoodCalculations();

            }
        }catch(Exception ex){

        }
    }

    public Dish findByName(){
        Dish dish = new Dish();
        String sql = "SELECT * FROM dishes WHERE dish_name = ?";
        Connection conn ;
        try{
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
            PreparedStatement prepare = conn.prepareStatement(sql);

            prepare.setString(1,dishName);

            ResultSet res = prepare.executeQuery();

            while(res.next()){
                dish.setDishName(res.getString("dish_name"));
                dish.setPrice(Double.parseDouble(res.getString("price")));
                dish.setDescription(res.getString("description"));
                dish.setId(res.getInt("id"));
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return dish;

    }
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        dishNameChoice.setItems(dishes);
        dishNameChoice.setConverter(new StringConverter<Dish>() {
            @Override
            public String toString(Dish dish) {
                return dish == null ? null : dish.getDishName();
            }

            @Override
            public Dish fromString(String string) {
                return dishes.stream().filter(dish -> dish.getDishName().equals(string)).findFirst().orElse(null);
            }
        });

        ingChoice.setItems(ingredients);
        ingChoice.setConverter(new StringConverter<Ingredient>() {
            @Override
            public String toString(Ingredient ingredient) {
                return ingredient == null ? null : ingredient.getIngredientName() + ", " + ingredient.getUnit().getUnitName();
            }

            @Override
            public Ingredient fromString(String s) {
                return ingredients.stream().filter(ing -> (ing.getIngredientName() + ", " + ing.getUnit().getUnitName()).equals(s)).findFirst().orElse(null);
            }
        });

        TableColumn ingName = new TableColumn("Ингредиент");
        TableColumn amount = new TableColumn<>("Количество");

        myIngs.getColumns().clear();
        myIngs.getColumns().addAll(ingName,amount);
        ingName.setCellValueFactory(new PropertyValueFactory<Ingredient, String>("ingredientName"));
        amount.setCellValueFactory(new PropertyValueFactory<Ingredient, Integer>("amountInOnePortion"));

        ingName.setMinWidth(174);
        amount.setMinWidth(95);
        // Add event handler for dish selection changes
        dishNameChoice.setValue(findByName());
        Dish preSelectedDish = dishNameChoice.getValue();
        if (preSelectedDish != null) {
            loadIngredientsForDish(preSelectedDish.getId()); // Load ingredients for the pre-selected dish
        }
        dishNameChoice.setOnAction(event -> {
            Dish selectedDish = dishNameChoice.getValue();
            if (selectedDish != null) {
                loadIngredientsForDish(selectedDish.getId());
            }
        });

    }

    private ObservableList<Ingredient> loadIngredientsForDish(int dishId) {
        ObservableList<Ingredient> ingredientsForDish = FXCollections.observableArrayList();
        String query = "SELECT i.id, i.name, u.id AS unit_id, u.name AS unit_name, fc.amountinoneportion " +
                "FROM foodcalculations fc " +
                "JOIN ingredients i ON fc.id_ingredients = i.id " +
                "JOIN units u ON i.id_units = u.id " +
                "WHERE fc.id_dishes = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, dishId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Ingredient ing = new Ingredient();
                ing.setId(rs.getInt("id"));
                ing.setIngredientName(rs.getString("name"));
                ing.setAmountInOnePortion(rs.getInt("amountinoneportion"));

                Unitt unit = new Unitt(rs.getInt("unit_id"), rs.getString("unit_name"));
                ing.setUnit(unit);

                ingredientsForDish.add(ing);

            }

            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        myIngs.setItems(ingredientsForDish);
        myIngs.refresh();
        return ingredientsForDish;
    }

}
