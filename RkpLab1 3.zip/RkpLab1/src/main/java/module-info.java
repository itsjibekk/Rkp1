module org.example.rkplab1 {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires net.synedra.validatorfx;
    requires org.kordamp.ikonli.javafx;
    requires org.kordamp.bootstrapfx.core;
    requires eu.hansolo.tilesfx;
    requires com.almasb.fxgl.all;
    requires javafx.graphics;
    requires java.persistence;
    requires spring.boot;
    requires spring.boot.autoconfigure;
    requires java.sql;
    requires java.desktop;
    requires com.opencsv;
    requires org.apache.poi.poi;
    requires org.apache.poi.ooxml;

    opens org.example.rkplab1 to javafx.fxml;
    exports org.example.rkplab1;
}