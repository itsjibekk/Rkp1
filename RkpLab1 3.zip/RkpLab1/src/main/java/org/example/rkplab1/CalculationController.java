package org.example.rkplab1;

public class CalculationController {
}
