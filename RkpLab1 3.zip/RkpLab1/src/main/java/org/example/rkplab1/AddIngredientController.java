package org.example.rkplab1;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.StringConverter;

import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class AddIngredientController implements Initializable {

    private static int count = 0;

    @FXML
    private Button addIngredientButton;

    @FXML
    private Button back;

    @FXML
    private TableView<Ingredient> myTable = new TableView<Ingredient>();

    @FXML
    private Button saveIngredient = new Button();

    @FXML
    private TextField unitTextField;

    @FXML
    private Button backToTheIngredients;

    @FXML
    private TextField ingredient;
    @FXML
    private TextField amountInOnePortion = new TextField();

    public ObservableList<Unitt> unitts =  loadUnittsFromDb();

    @FXML
    private ChoiceBox<Unitt> menuButton = new ChoiceBox<>(unitts);


    public CookBookStart cookBookStart = new CookBookStart();
    public ObservableList<Dish> dishes = cookBookStart.loadDataFromDatabase();


    @FXML
    private Button delete;

    @Override
    public void initialize(URL location, ResourceBundle resources) {


        TableColumn id = new TableColumn("ID");
        TableColumn ingredientName = new TableColumn("Наименование ингредиента");
        TableColumn<Ingredient,String> unit = new TableColumn<>("Единица измерения");

        myTable.getColumns().addAll(id,ingredientName,unit);

        final ObservableList<Ingredient> data = loadDataFromDatabase();

        id.setCellValueFactory(new PropertyValueFactory<Ingredient, Integer>("id"));
        ingredientName.setCellValueFactory(new PropertyValueFactory<Ingredient,String>("ingredientName"));
        unit.setCellValueFactory(new PropertyValueFactory<>("unitName"));

        myTable.setItems(data);

        menuButton.setItems(unitts);
        menuButton.setConverter(new StringConverter<Unitt>() {
            @Override
            public String toString(Unitt unit) {
                return unit == null ? null : unit.getUnitName();
            }

            @Override
            public Unitt fromString(String string) {
                return unitts.stream().filter(unit -> unit.getUnitName().equals(string)).findFirst().orElse(null);
            }
        });

        saveIngredient.setOnAction(event -> {
            String inputData = ingredient.getText().trim();
            if (inputData.isEmpty()) {
                showAlert("Нельзя сохранять пустую строку!");
            } else if (isDuplicate(inputData)) {
                showAlert("Такой ингредиент уже существует!");
            } else {
                setSaveIngredient();
                showAlert("Ингредиент сохранен успешно!");
            }
        });

    }

    public static boolean isDuplicate(String value) {
        String query = "SELECT COUNT(*) FROM ingredients WHERE name = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, value);
            ResultSet rs = pstmt.executeQuery();
            rs.next();
            return rs.getInt(1) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Уведомление");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private ObservableList<Ingredient> loadDataFromDatabase() {
        ArrayList<Ingredient> ingredients = new ArrayList<>();
        try {
            Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
            Statement stmt = conn.createStatement();
            Statement statement = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String queryIng = "SELECT * FROM ingredients";
            ResultSet rs = stmt.executeQuery(queryIng);

            String query2 = "SELECT f.name\n" +
                    "FROM units f\n" +
                    "         INNER JOIN ingredients d ON f.id = d.id_units\n" +
                    "WHERE d.id_units = ";

            ResultSet rs2 = null;

            while (rs.next()) {
                String ingredientNameDb = rs.getString("name");
                int id = rs.getInt("id");
                int unitId = rs.getInt("id_units");
                rs2 = statement.executeQuery(query2 + unitId);
                String unitName = rs2.first() ? rs2.getString("name") : null;
                ingredients.add(new Ingredient(id, ingredientNameDb, unitName));

            }
            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return FXCollections.observableArrayList(ingredients);

    }


    public void deleteButton(){
        Ingredient selectedItem = myTable.getSelectionModel().getSelectedItem();
        myTable.getItems().remove(selectedItem);
        myTable.refresh();
        Connection conn = null;
        try {
            String query = "DELETE FROM ingredients where id = ?";
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setLong(1,selectedItem.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
    public void backButton(){
        new Utils().loadNewScene("/org/example/rkplab1/hello-view.fxml",back);
    }

    public void addIngredients(){
        new Utils().loadNewScene("/org/example/rkplab1/addIngredientsBlank.fxml",back);
    }

    public void setBackToTheIngredients(){
       new Utils().loadNewScene("/org/example/rkplab1/ingredients.fxml",backToTheIngredients);
    }

    public void setSaveIngredient(){
        Unitt selectedUnit = menuButton.getValue();
        String query = "INSERT INTO ingredients(name,id_units) VALUES(?,?)";
        String ingredientNameText = ingredient.getText();
        try {
            Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
            PreparedStatement stat = conn.prepareStatement(query);
            stat.setString(1,ingredientNameText);
            stat.setInt(2,selectedUnit.getId());
            stat.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    ObservableList<Unitt> loadUnittsFromDb(){
        List<Unitt> myUnits = new ArrayList<>();
        Connection conn = null;
        try {
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
            Statement stmt = conn.createStatement();

            String query = "SELECT * FROM units;";
            ResultSet resultSet = stmt.executeQuery(query);
            Unitt unitt;
            while(resultSet.next()){
                unitt = new Unitt();
                unitt.setId(resultSet.getInt("id"));
                unitt.setUnitName(resultSet.getString("name"));
                myUnits.add(unitt);
            }

            conn.close();
            stmt.close();
            resultSet.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return FXCollections.observableArrayList(myUnits);
    }
}
