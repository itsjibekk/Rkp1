package org.example.rkplab1;

import java.sql.Timestamp;

public class Orderr {

    private int id;
    private double total;
    private String orderDate;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public Orderr(int id, double total, String orderDate) {
        this.id = id;
        this.total = total;
        this.orderDate = orderDate;
    }
}
