package org.example.rkplab1;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class TypesController implements Initializable {

    @FXML
    private Button back;
    @FXML
    private Button addUnit;

    @FXML Button delete;

    @FXML Button saveUnit = new Button();

    @FXML Button backToTheMenu;

    @FXML TextField unit = new TextField();



    @FXML
    private TableView<FoodType> myTable = new TableView<>();

    public void backButton(){
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/rkplab1/hello-view.fxml"));
            Parent root = loader.load();

            Stage newStage = new Stage();
            newStage.setScene(new Scene(root,880,700));

            Stage currentStage = (Stage) back.getScene().getWindow();
            currentStage.close();

            newStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setSaveUnit(){
        String unit = this.unit.getText();
        String query = "INSERT INTO food_type(type_name) values(?)";
        try {
            Connection con  = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
            PreparedStatement prStat = con.prepareStatement(query);
            prStat.setString(1,unit);
            prStat.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void backToMenu(){
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/rkplab1/typesTable.fxml"));
            Parent root = loader.load();

            Stage newStage = new Stage();
            newStage.setScene(new Scene(root,880,700));

            Stage currentStage = (Stage) backToTheMenu.getScene().getWindow();
            currentStage.close();

            newStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void deleteButton(){
        FoodType selectedItem = myTable.getSelectionModel().getSelectedItem();
        myTable.getItems().remove(selectedItem);
        myTable.refresh();
        Connection conn = null;
        try {
            String query = "DELETE FROM food_type where id = ?";
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setLong(1,selectedItem.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public void addUnit(){
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/rkplab1/types.fxml"));
            Parent root = loader.load();

            Stage newStage = new Stage();
            newStage.setScene(new Scene(root,880,700));

            Stage currentStage = (Stage) addUnit.getScene().getWindow();
            currentStage.close();

            newStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        TableColumn id = new TableColumn("ID");
        TableColumn unitName = new TableColumn("Наименование типа");

        myTable.getColumns().addAll(id,unitName);

        final ObservableList<FoodType> data = loadDataFromDatabase();

        id.setCellValueFactory(new PropertyValueFactory<Dish, Integer>("id"));
        unitName.setCellValueFactory(new PropertyValueFactory<Dish, Integer>("typeName"));

        myTable.setItems(data);

        saveUnit.setOnAction(event -> {
            String inputData = unit.getText().trim();
            if (inputData.isEmpty()) {
                showAlert("Нельзя сохранять пустую строку!");
            } else if (isDuplicate(inputData)) {
                showAlert("Такой тип блюда уже существует!");
            } else {
                setSaveUnit();
                showAlert("Тип блюда сохранен успешно!");
            }
        });

    }

    public static boolean isDuplicate(String value) {
        String query = "SELECT COUNT(*) FROM food_type WHERE type_name = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, value);
            ResultSet rs = pstmt.executeQuery();
            rs.next();
            return rs.getInt(1) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Уведомление");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private ObservableList<FoodType> loadDataFromDatabase() {
        ArrayList<FoodType> types = new ArrayList<>();
        try {
            Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");
            Statement stmt = conn.createStatement();
            String query = "SELECT * FROM food_type";
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                String typeName = rs.getString("type_name");
                int id = rs.getInt("id");
                types.add(new FoodType(id,typeName));
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return FXCollections.observableArrayList(types);
    }
}
