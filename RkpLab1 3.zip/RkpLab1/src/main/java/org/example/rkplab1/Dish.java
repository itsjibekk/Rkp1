package org.example.rkplab1;

import java.util.Objects;

public class Dish {

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Dish dish = (Dish) o;
        return id == dish.id && Double.compare(price, dish.price) == 0 && Objects.equals(dishName, dish.dishName) && Objects.equals(foodType, dish.foodType) && Objects.equals(description, dish.description) && Objects.equals(typeName, dish.typeName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, dishName, price, foodType, description, typeName);
    }

    private int id;

    private String dishName;

    private double price;

    private FoodType foodType;

    private String description;

    private String typeName;

    public FoodType getFoodType() {
        return foodType;
    }

    public void setFoodType(FoodType foodType) {
        this.foodType = foodType;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = foodType.getTypeName();
    }

    public Dish(int id, double price) {
        this.id = id;
        this.price = price;
    }


    public Dish(int id, String dishName, double price) {
        this.id = id;
        this.dishName = dishName;
        this.price = price;

    }

    @Override
    public String toString() {
        return "Dish{" +
                "id=" + id +
                ", dishName='" + dishName + '\'' +
                ", price=" + price +
                ", foodType=" + typeName +
                ", description='" + description + '\'' +
                '}';
    }

    public Dish() {
    }

    public Dish(int id, String dishName, int price, String foodType, String description) {
        this.id = id;
        this.dishName = dishName;
        this.price = price;
        this.typeName = foodType;
        this.description = description;
    }

    public Dish(int id, String dishName, int price, String description) {
        this.id = id;
        this.dishName = dishName;
        this.price = price;
        this.description = description;
    }

    public Dish(int id, String dishName, double price, String description) {
        this.id = id;
        this.dishName = dishName;
        this.price = price;
        this.description = description;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDishName() {
        return dishName;
    }

    public void setDishName(String dishName) {
        this.dishName = dishName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public FoodType getType() {
        return foodType;
    }

    public void setType(FoodType type) {
        this.foodType = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;



    }

}

