package org.example.rkplab1;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.StringConverter;

import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.ResourceBundle;

public class ReceiptsController implements Initializable {

    @FXML
    Button backToMain;


    @FXML
    Button addRecipe;

    @FXML
    Button updateRecipe;

    @FXML
    TextField amountText;

    @FXML
    TableView<Ingredient> myIngs = new TableView<>();

    @FXML
    Button deleteRecipe;

    @FXML
    TableView myRecipes = new TableView<>();

    @FXML
    void setBackToMain(){
        new Utils().loadNewScene("/org/example/rkplab1/hello-view.fxml",backToMain);
    }

    @FXML
    void setAddRecipe(){
        new Utils().loadNewScene("/org/example/rkplab1/addRecipe.fxml",updateRecipe);
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        ObservableList<String> list = getCalculs();
        myRecipes.setItems(list);

        TableColumn<String, String> dishName = new TableColumn<>("Название блюда");
        TableColumn<String, String> action = new TableColumn<>("Action");

        // Set minimum widths
        dishName.setMinWidth(616);

        // Define how to display data in columns
        dishName.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue()));

        myRecipes.getColumns().addAll(dishName);

        // Set up dishNameChoice and ingChoice as before

    }

    public void delete(){

    }

    private ObservableList<String> getCalculs() {
        String query = "SELECT distinct d.dish_name\n" +
                "FROM foodcalculations fc\n" +
                "         JOIN dishes d ON fc.id_dishes = d.id;";
        Connection conn = null;
        ObservableList<String> list = FXCollections.observableArrayList();
        try {
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/menus_db", "postgres", "postgres");

            PreparedStatement stm = conn.prepareStatement(query);
            ResultSet res = stm.executeQuery();
            while (res.next()) {
                list.add(res.getString("dish_name"));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return list;
    }

    public void update(){
        UpdateRecipeController updateRecipeController = new UpdateRecipeController();
        updateRecipeController.setDishName(getDish());
        setAddRecipe();

    }

    @FXML
    public void add(){
        new Utils().loadNewScene("/org/example/rkplab1/adddRecipe.fxml",addRecipe);
    }

    public String getDish(){
        String dishName = (String) myRecipes.getSelectionModel().getSelectedItem();
        return dishName;
    }





}
